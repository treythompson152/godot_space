# godot_space
Example space shooter game for coderdojo

Play online at https://electronstudio.github.io/godot_space/

# Credits

Graphics

Bonsaiheldin | http://bonsaiheld.org https://opengameart.org/content/stars-parallax-backgrounds

http://millionthvector.blogspot.com/

Sound:

https://opengameart.org/content/explosion-0

